﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Order_Form_MVC.Models;

namespace Order_Form_MVC.Controllers
{
    public class OrdersController : Controller
    {

        private Order_FormContext db = new Order_FormContext(); // initialize the database context

        // GET: Order
        public ActionResult Index()
        {
            var orders = db.Order.ToList();
            return View(orders);
        }

        // GET: Order/Create
        public ActionResult Create()
        {
            var customers = db.Customer.ToList();
            var products = db.Product.ToList();
            ViewBag.Customers = customers;
            ViewBag.Products = products;
            return View();
        }

        // POST: Order/Create
        [HttpPost]
        public ActionResult Create(Order order)
        {
            if (ModelState.IsValid)
            {
                db.Order.Add(order);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            var customers = db.Customer.ToList();
            var products = db.Product.ToList();
            ViewBag.Customers = customers;
            ViewBag.Products = products;
            return View(order);
        }

        // GET: Order/Edit/5
        public ActionResult Edit(int id)
        {
            var order = db.Order.Find(id);

            var customers = db.Customer.ToList();
            var products = db.Product.ToList();

            var viewModel = new OrderViewModel()
            {
                Id = order.Id,
                CustomerId = order.CustomerId,
                ProductId = order.ProductId,
                Remarks = order.Remarks,
                Customers = customers,
                Products = products
            };

            return View(viewModel);
        }

        // POST: Order/Edit/5
        [HttpPost]
        public ActionResult Edit(OrderViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var order = db.Order.Find(viewModel.Id);

                order.CustomerId = viewModel.CustomerId;
                order.ProductId = viewModel.ProductId;
                order.Remarks = viewModel.Remarks;

                db.Entry(order).State = EntityState.Modified;
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(viewModel);
        }

        // GET: Order/Delete/5
        public ActionResult Delete(int id)
        {
            var order = db.Order.Find(id);

            db.Order.Remove(order);
            db.SaveChanges();

            return RedirectToAction("Index");
        }

    }
}


