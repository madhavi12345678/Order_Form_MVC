﻿using Order_Form_MVC.Models;

namespace Order_Form_MVC.Controllers
{
    internal class OrderViewModel
    {
        public OrderViewModel()
        {
        }

        public int Id { get; set; }
        public int? CustomerId { get; set; }
        public int? ProductId { get; set; }
        public string Remarks { get; set; }
        public List<Customer> Customers { get; set; }
        public List<Product> Products { get; set; }
    }
}